const CONSTANTS = {
    MODULE_NAME: "sequencer",
    FLAG_NAME: "effects"
}

export default CONSTANTS;